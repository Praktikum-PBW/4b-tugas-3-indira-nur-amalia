const fibonaci=()=>{

let angka =  parseInt(prompt(' Masukkan Angka Untuk Deret Fibonacci '));

let fib = []; 
fib[0] = 0;
fib[1] = 1;
for (let i = 2; i <= angka; i++) {
 fib[i] = fib[i - 2] + fib[i - 1];
}
return fib.join(' , ');
}



console.log(fibonaci());
